import time
import pandas as pd
import os
from sendMailAttachments import send_mail
try:
    excel_file = "daily_report_0901.xlsx"  # 模板文件
    email_column = "接收人邮箱"  # 邮件接收人所在列表头
    email_from = "FieldCollectionQM@homecredit.cn"  # 发送方邮件地址
    email_bcc = ['sucre.xu@homecredit.cn']  # 隐藏的收件人列表，填写自己的邮件地址，接收邮件作为已发送依据暂存
    email_subject = excel_file.replace(".xlsx", "")  # "通知"  # 邮件标题
    email_body = """
    Dear,
    请查收附件报表，谢谢。
    Best regards,
    Field collection QM
    """  # 邮件正文

    currentPath = os.path.dirname(__file__)
    timeString = time.strftime("%Y%m%d%H%M%S")
    attachmentFolder = currentPath + '/attachments_' + timeString
    if os.path.isdir(attachmentFolder) is False:
        os.mkdir(attachmentFolder)
    df = pd.read_excel(currentPath + "/" + excel_file)
    unique_employees = df[email_column].unique()
    for employee in unique_employees:
        tf = (df[email_column] == employee)
        file_name = attachmentFolder + "/" + str(employee) + ".xlsx"
        df.loc[tf].to_excel(file_name, index=False)
        send_mail(email_from, [employee], email_subject, email_body, [
                  file_name], "relay.homecredit.cn:25", email_bcc)
        print(employee + " √")
except Exception as e:
    print(e.__str__())
