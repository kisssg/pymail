import requests  
from getTK  import Py4Js  
    
def translate(content):   
    if len(content) > 4891:    
        print("Content input too long!!!")    
        return  
    js=Py4Js()
    tk=js.getTk(content)
 
    param = {'tk': tk, 'q': content}
 
    result = requests.get("""http://translate.google.cn/translate_a/single?client=t&sl=en
        &tl=ja&hl=ja&dt=at&dt=bd&dt=ex&dt=ld&dt=md&dt=qca&dt=rw&dt=rm&dt=ss
        &dt=t&ie=UTF-8&oe=UTF-8&clearbtn=1&otf=1&pc=1&srcrom=0&ssel=0&tsel=0&kc=2""", params=param)
 
    #返回的结果为Json，解析为一个嵌套列表
    # for text in result.json():
        # print(text)
    return(result.json()[0][0][0]+"\n" +result.json()[0][1][2])
     
    
def main():
    content = ""
    while(content!='exit'):
        content = input("Please input('exit' to exit):")
        print(translate(content))
        
if __name__ == "__main__":    
    main()