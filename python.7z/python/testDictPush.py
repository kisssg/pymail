import os
def solve(s):
    ''' print numbers up to s.

        s should be an integer
    '''
    final=""
    for i in range(s):
        print(i)

def fibo(n):
    '''a func return the fibonacci number up to n.
    
    e.g. fibo(5) will return 3. '''
    a, b = 0, 1
    while a < n:
        print(a,end=' ')
        a, b = b, a+b
    print()

if(__name__== "__main__"):
    fibo(50)
    with open('shows.csv') as f:
        print(f.read())
    print(f.closed)
    try:
        fibo(50)
        print(os.getcwd())
        print("raised name error")
    except (NameError, ValueError, ZeroDivisionError, TypeError) as n:
        print(n)
    else:
        print("try else block will show when there is no exception raised")
    finally:
        print("try finally block will show whatever happened")
else:
    print(__name__)