import random
goal=random.randint(1,100)
while(True):
    guess=input('Guess the number between 1-100:')
    if(int(guess)>goal):
        print('Too big!')
        continue
    if(int(guess)<goal):
        print('Too small!')
        continue
    print('You goal! It\'s',goal)
    break