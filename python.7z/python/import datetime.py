import datetime
from getpass import getpass
from mysql.connector import connect
import xlwings as xw

cnx = connect(
    host="10.67.0.208",
    user=input("Enter username: "),
    password=getpass("Enter password: "),
    database="qm_oa")
cursor = cnx.cursor()

query = ("select * from actions")

hire_start = datetime.date(1999, 1, 1)
hire_end = datetime.date(1999, 12, 31)

# cursor.execute(query, (hire_start, hire_end))
cursor.execute(query, multi=True)

# for (first_name, last_name, hire_date) in cursor:
#   print("{}, {} was hired on {:%d %b %Y}".format(
#     last_name, first_name, hire_date))

for (action) in cursor:
    print(action)
cursor.close()
cnx.close()
