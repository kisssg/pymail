from getpass import getpass
from mysql.connector import connect, Error

try:
    with connect(
        host="10.67.0.208",
        user=input("Enter username: "),
        password=getpass("Enter password: "),
    ) as connection:
        cnx=connection
except Error as e:
    print(e)

cursor = cnx.cursor()

cursor.execute("select * from qm_oa.actions")

cursor.close()
cnx.close()
