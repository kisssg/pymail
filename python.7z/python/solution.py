class Solution:
    def solve(self, s, k):
        sp = 0
        max = 0
        for i in s:
            if i == ".":
                sp += 1
            else:
                sp = 0
            if sp > max:
                max = sp
        x = len(s) - 1
        y = 0
        edge = 0
        while x >= len(s) // 2:
            if (s[x] == ".") or (s[y] == "."):
                edge += 1
            else:
                break
            x -= 1
            y += 1
        if max < edge * 2:
            max = edge * 2
        return edge

s = Solution()
a = s.solve("..x.x.",3)
print(a)
