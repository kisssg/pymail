import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

speed = [99,86,87,88,111,86,103,94,78,77,85,86]

ages = [5,31,43,48,50,41,7,11,15,39,80,82,32,2,8,6,25,36,27,61,31]

# x = numpy.mean(speed)
# x=numpy.median(speed)
# x=stats.mode(speed)
# x=numpy.std(speed)
# x=numpy.percentile(ages,90)
x=np.random.normal(5.0,1.0,100)
y = np.random.normal(10.0, 2.0, 100)
plt.scatter(x,y)
# plt.hist(x,1000)
plt.show()

print(np.__version__)