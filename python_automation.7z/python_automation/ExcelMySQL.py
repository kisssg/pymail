import xlrd
import xlwt
import os
import pandas as pd
from configparser import ConfigParser
import mysql.connector

class ExcelMySQL(object):
    def __init__(self):
        self.Title = "Work with Excel Example";
        config = ConfigParser()
        config.read_file(open('mypy.ini'))
        database = config.get("dbinfo","database")
        dbusername = config.get("dbinfo","dbusername")
        dbpassword = config.get("dbinfo","dbpassword")
        dbhost = config.get("dbinfo","dbhost")
        self.myConnection = mysql.connector.connect(
          host=dbhost,
          user=dbusername,
          password=dbpassword,
          database=database,
          )
    def ReadFromExcel(self):
        rootPath = os.getcwd()
        rootPath=rootPath+"/excelFolder/";
        loc = (rootPath+"emailList.xlsx"); 
  
        wb = xlrd.open_workbook(loc) 
        sheet = wb.sheet_by_index(0) 
        for i in range(sheet.nrows): 
                print(sheet.cell_value(i, 0),sheet.cell_value(i, 1)) 
        print("Successfully retrieved all excel data");
    def writeToExcel2(self):
        rootPath = os.getcwd()
        rootPath=rootPath+"/excelFolder/newFile.xlsx";       
        
        workbook = xlwt.Workbook(encoding='utf-8')
        worksheet = workbook.add_sheet("mysheet1",cell_overwrite_ok=True)
        worksheet.Title = "Email List";     
    
        fileds = [u'ID',u'Name',u'Email']
        for filed in range(0,len(fileds)):
            worksheet.write(0,filed,fileds[filed])           
     
        workbook.save(rootPath);
         
        print("Successfully created excel file");
    def writeToExcel(self,query,filename,saveto):
        cur= self.myConnection.cursor()
        querys = query.split(";")
        for q in querys:
            cur.execute(q)
        if not os.path.isdir(saveto):
            os.mkdir(saveto)
        # df=sql.read_sql(query,self.myConnection)
        df = pd.DataFrame(cur,columns=cur.column_names)
        df.to_excel(saveto + '\\' + filename,index=False)         
        print("Executed successfully.")
    def query2df(self,query):
        cur= self.myConnection.cursor()
        querys = query.split(";")
        for q in querys:
            cur.execute(q)
        df = pd.DataFrame(cur,columns=cur.column_names)
        return df

