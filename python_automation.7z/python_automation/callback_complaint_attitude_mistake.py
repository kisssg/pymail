from ExcelMySQL import ExcelMySQL
import datetime
from sendMailAttachments import send_mail
wq = ExcelMySQL()

weekday=datetime.date.today().weekday()
start_day = datetime.date.today() - datetime.timedelta(weekday+3)
end_day = start_day + datetime.timedelta(6)
filename = "Callback态度+过错{:%m%d}-{:%m%d}.xlsx".format(start_day,end_day)
# saveto = "\\\\hc.cn\hccdfs\Restricted\DptRisk\Collection\Late collection QC\FC QC\\video data\VRD每周核查数据\\{:%Y%m}".format(datetime.date.today())
saveto=".\\{:%Y%m}".format(datetime.date.today())
query = """
SELECT
    f.*,
    f.complaint_obj as "Q8-2 投诉对象",
    s.valid_complaint_2nd as "C-6.是否为有效投诉_二次回访",
    s.call_time_2nd  as "二次回电/跟进处理日期"
FROM
  `callback` f
LEFT JOIN `recallback` s ON s.callback_id = f.id
WHERE
    f.is_harassed = 'Y 是'               -- Q7是否有困扰
    AND f.got_understood != 'Y 是'        -- Q14是否接受解释，包含“-” 和 “N 否”
    AND f.complaint_obj not in ("无法确定","业务员")    --  "Q8-2 投诉对象"
    AND call_time_2nd BETWEEN '{} 00:00:00' AND '{} 23:00:00'     -- 二次回电/跟进处理日期
    AND s.valid_complaint_2nd='有效'       -- C-6.是否为有效投诉_二次回访
ORDER BY id

-- 这个SQL是用二次回访的时间限定避免遗漏数据，所有（态度+过错）投诉都会进行二次回访
-- 流程和其他的投诉不需要二次回访，所以这个SQL导出不会出现
""".format(start_day,end_day)

wq.writeToExcel(query,filename,saveto)

mailbody="""Dear Xiaohong,

有效违规（态度+过错）{:%m%d}-{:%m%d}:请查看附件。

Best Regards,
QC Data Team

""".format(start_day,end_day)
sendto=['Yue.Zhao@homecredit.cn','Guanhua.Zhang@homecredit.cn','Lvnhoor.Lv@homecredit.cn','Jenny.ZhangTJ@homecredit.cn','Ye.CHEN@homecredit.cn','Fifi.ZHENG@homecredit.cn','Danielle.Wang@homecredit.cn','lina.deng@homecredit.cn','feng.lin@homecredit.cn','lingling.zhuchs@homecredit.cn']
# sendto=['sucre.xu@homecredit.cn']
send_mail("sucre.xu@homecredit.cn",sendto,"callback投诉需登记DCM的数据01",mailbody,[saveto + "\\" + filename ],"relay.homecredit.cn")
