from ExcelMySQL import ExcelMySQL
import datetime

def test():
	pass
wq = ExcelMySQL()

weekday=datetime.date.today().day
start_day = datetime.date.today() - datetime.timedelta(weekday-1)
today = datetime.date.today()
if(today.month == 1):
        last_month_day1 = (datetime.date(today.year-1,12,1))
else:
        last_month_day1 = (datetime.date(today.year,today.month-1,1))
if(datetime.date.today().day < 10):
	start_day = last_month_day1
end_day = datetime.date.today()
start_day = datetime.date(2022,10,1)
end_day =  datetime.date(2022,11,1)
filename = "投诉协调组有效违规{:%m%d}-{:%m%d}.xlsx".format(start_day,end_day)
# saveto = "\\\\Hcg.homecredit.net\\cndata\HCCDFS\Restricted\DptRisk\Collection\Late collection QC\FC QC\\video data\VRD每周核查数据\\{:%Y%m}".format(datetime.date.today())
saveto=".\\{:%Y%m}".format(datetime.date.today())
query = """
SELECT d.owner,left(picked_at,10) as date,min(picked_at) as first_pick, max(s.created_at) as last_submit,count(*) as
count,sum(s.cost) as duration,hour(timediff(max(s.created_at),min(picked_at)))+minute(timediff(max(s.created_at),min(picked_at)))/60+second(timediff(max(s.created_at),min(picked_at)))/3600 as "last_minus_first(hour)",(sum(s.cost)/3600) as duration_hour FROM r_recordings d left join r_recording_scores s on d.id=s.data_id where d.deleted_at is
null and owner is not null and picked_at between '{}' and '{}' group by d.owner,date   
""".format(start_day,end_day)
# wq.writeToExcel(query,filename,saveto)
df = wq.query2df(query)
from openpyxl import load_workbook
from openpyxl.utils.dataframe import dataframe_to_rows

wb = load_workbook("templates/pick_check_range_agregated.xlsx")
ws_data = wb['data']
ws_data.delete_cols(1, 56)
ws_data.delete_rows(1, 8000)
for r in dataframe_to_rows(df, index=False, header=True):
    ws_data.append(r)
ws = wb["pivot"]
pivot = ws._pivots[0] # any will do as they share the same cache
pivot.cache.refreshOnLoad = True
wb.save("Pick_check_range_agregated{}.xlsx".format(start_day.strftime("%Y%m")))