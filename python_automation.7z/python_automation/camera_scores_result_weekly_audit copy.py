from ExcelMySQL import ExcelMySQL
import datetime
wq = ExcelMySQL()


today = datetime.date.today()
if(today.month == 1):
    last_month_day1 = (datetime.date(today.year-1, 12, 1))
else:
    last_month_day1 = (datetime.date(today.year, today.month-1, 1))

weekday = datetime.date.today().day
start_day = datetime.date.today() - datetime.timedelta(weekday-1)
if(datetime.date.today().day < 10):
    start_day = last_month_day1
end_day = datetime.date.today()

filename = "Pick_check_original {:%m%d}-{:%m%d}.xlsx".format(
    start_day, end_day)


query = """
SELECT owner,contract,left(d.picked_at,10) as date,d.picked_at, s.created_at as submited_at,s.cost as check_duration_seconds,d.DURATION as rec_duration FROM r_recordings d left join r_recording_scores s on d.id=s.data_id  where d.deleted_at is null and owner is not null and picked_at between '{}' and '{}'

""".format(start_day, end_day)

saveto=".\\{:%Y%m}".format(datetime.date.today())
wq.writeToExcel(query, filename, saveto)
