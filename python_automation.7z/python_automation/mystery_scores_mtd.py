from ExcelMySQL import ExcelMySQL
import datetime
from sendMailAttachments import send_mail
wq = ExcelMySQL()

weekday=datetime.date.today().day
start_day = datetime.date.today() - datetime.timedelta(weekday-1)
today = datetime.date.today()
if(today.month == 1):
        last_month_day1 = (datetime.date(today.year-1,12,1))
else:
        last_month_day1 = (datetime.date(today.year,today.month-1,1))
if(datetime.date.today().day < 10):
	start_day = last_month_day1
end_day = datetime.date.today()
# start_day = datetime.date(2021,9,1)
# end_day =  datetime.date(2021,9,30)
filename = "mystery_scores_mtd{:%m%d}-{:%m%d}.xlsx".format(start_day,end_day)
# saveto = "\\\\Hcg.homecredit.net\\cndata\HCCDFS\Restricted\DptRisk\Collection\Late collection QC\FC QC\\video data\VRD每周核查数据\\{:%Y%m}".format(datetime.date.today())
saveto=".\\{:%Y%m}".format(datetime.date.today())
query = """
SELECT
	id,
	checked_batch,
	LCS,
	agency,
	region,
	contract_no,
	collection_date,
	collection_type,
	concat("'",contact_no) AS contact_no,
	item1,
	item2,
	item3,
	item4,
	item5,
	item6,
	item8,
	item9,
	item10,
	item11,
	item12,
	item13,
	item14,
	item15,
	item16,
	score,
	issue_detail,
	qc,
	answer_scenario,
	create_time,
	edit_time,
	call_back_result,
	reserved_number,
	cid, (
		SELECT
			NAME
		FROM
			fake_contracts a
		WHERE
			a.id = b.cid
            AND deleted_at is null
	) AS client_name
FROM
	`mystery_scores1` b
WHERE
	create_time BETWEEN '{} 00:00:00' AND '{} 23:59:59'
	AND deleted_at is null
ORDER BY id
""".format(start_day,end_day)
wq.writeToExcel(query,filename,saveto)

mailbody="""Dear Echo,

秘密核查结果汇总MTD{:%m%d}-{:%m%d}:请查看附件。

Best Regards,
QC Data Team

""".format(start_day,end_day)
sendto=['echo.he@homecredit.cn','jing.sheng@homecredit.cn','xiaoqiong.yang@homecredit.cn','feng.lin@homecredit.cn','sucre.xu@homecredit.cn']
# sendto=['sucre.xu@homecredit.cn']
send_mail("sucre.xu@homecredit.cn",sendto,"秘密核查结果汇总MTD{:%m%d}-{:%m%d}".format(start_day,end_day),mailbody,[saveto + "\\" + filename ],"relay.homecredit.cn")
