# txt2epub.py
# coding: utf-8

from zipfile import ZipFile
import os
import shutil
import glob

# 书籍信息
title = '耶林-为权利而斗争'
author = '耶林'
creator = '耶林/电子书：Sucre'
description = '法哲学书丛'
# 章节文件
os.chdir('text_files')
txtlist = glob.glob("*.txt")
print(txtlist)
# 临时工作目录
if(os.path.exists('tmp') == False):
    os.mkdir('tmp')

# tmp/mimetype 文件
tf = open('tmp/mimetype', 'w', encoding='utf-8')
tf.write('application/epub+zip')
tf.close()

# tmp/META-INF 目录
if(os.path.exists('tmp/META-INF') == False):
    os.mkdir('tmp/META-INF')
# tmp/META-INF/container.xml 文件, 指定opf文件
tf = open('tmp/META-INF/container.xml', 'w', encoding='utf-8')
tf.write('''<?xml version="1.0" encoding="utf-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
   <rootfiles> <rootfile full-path="OPS/content.opf" media-type="application/oebps-package+xml"/> </rootfiles>
</container>
''')
tf.close()

# tmp/OPS 目录 主要存在这里
if(os.path.exists('tmp/OPS') == False):
    os.mkdir('tmp/OPS')

# 封面图片
if os.path.isfile('cover.jpg'):
    import shutil
    shutil.copyfile('cover.jpg', 'tmp/OPS/cover.jpg')
    print('Cover found!')

# 准备opf文件信息,包含目录文件封面文件信息
opfcontent = '''<?xml version="1.0" encoding="UTF-8"?>
<package xmlns:opf="http://www.idpf.org/2007/opf" unique-identifier="bookid" xmlns="http://www.idpf.org/2007/opf" version="2.0">
<metadata xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:opf="http://www.idpf.org/2007/opf" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:dc="http://purl.org/dc/elements/1.1/">
%(metadata)s
<meta name="cover" content="cover"/>
</metadata>
<manifest>
%(manifest)s
<item id="ncx" href="content.ncx" media-type="application/x-dtbncx+xml"/>
<item id="cover" href="cover.jpg" media-type="image/jpeg"/>
<item href="book.css" id="css" media-type="text/css"/>
</manifest>
<spine toc="ncx">
%(ncx)s
</spine>
</package>
'''
dc = '<dc:%(name)s>%(value)s</dc:%(name)s>'
item = "<item id='item%(id)d' href='%(url)s' media-type='application/xhtml+xml'/>"
itemref = "<itemref idref='item%(id)d'/>"

metadata = '\n'.join([
    dc % {'name': 'title', 'value': title},
    dc % {'name': 'author', 'value': author},
    dc % {'name': 'creator', 'value': creator},
    dc % {'name': 'description', 'value': description},
])

manifest = []
ncx = []

# 根据每章节生成内容, txt => html
for i, txt in enumerate(txtlist):
    content = open(txt, 'r', encoding='utf-8').read().split('\n')
    content = ['<div><p class="content">%s</p></div>' % line for line in content]
    print(txt)
    tf = open('tmp/OPS/ch%s.html' % repr(i+1), 'w', encoding='utf-8')
    tf.write('''<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"><html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-CN" lang="zh-CN">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link type="text/css" rel="stylesheet" href="book.css"/>
<title>%(title)s</title>
</head>
<body>
<div>
<h2>%(title)s</h2>
''' % {'title': txt.replace('.txt', '')})
    tf.write('\n'.join(content))
    tf.write('''</div>
</body>
</html>''')
    tf.close()
    manifest.append(item % {'id': i+1, 'url': 'ch'+repr(i+1)+'.html'})
    ncx.append(itemref % {'id': i+1})

manifest = '\n'.join(manifest)
ncx = '\n'.join(ncx)

# 生成opf文件
tf = open('tmp/OPS/content.opf', 'w', encoding='utf-8')
tf.write(opfcontent % {'metadata': metadata,
                       'manifest': manifest, 'ncx': ncx, })
tf.close()

# 准备目录文件ncx内容
ncx = '''<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
   <head>
      <meta name="dtb:uid" content="bookid"/>
      <meta name="dtb:depth" content="0"/>
      <meta name="dtb:totalPageCount" content="0"/>
      <meta name="dtb:maxPageNumber" content="0"/>
   </head>
 <docTitle><text>%(title)s</text></docTitle>
 <docAuthor><text>%(author)s</text></docAuthor>
<navMap>
%(navpoints)s
</navMap>
</ncx>
'''

css = '''
/* CSS Document */
@charset "utf-8";

/*正文*/
.content1{font-size:1.2em;text-align:justify;text-indent:2em;line-height:1.5em;}
.content{    
text-indent: 2em;
display: block;
margin-block-start: 1em;
margin-block-end: 1em;
margin-inline-start: 0.5em;
margin-inline-end: 0.5em;
}
.inscribe{margin-right:2em; text-align:right;margin-top:1em;}

'''

navpoint = '''<navPoint id='item%d' class='level1' playOrder='%d'>
<navLabel> <text>%s</text> </navLabel>
<content src='%s'/></navPoint>'''

navpoints = []
for i, txt in enumerate(txtlist):
    navpoints.append(navpoint % (
        i+1, i+1, txt.replace('.txt', ''), 'ch'+repr(i+1)+'.html'))

# 生成目录文件
tf = open('tmp/OPS/content.ncx', 'w', encoding='utf-8')
tf.write(ncx % {
    'title': title, 'author': author,
    'navpoints': '\n'.join(navpoints)})
tf.close()

# 生成CSS文件
tf = open('tmp/OPS/book.css', 'w', encoding='utf-8')
tf.write(css)
tf.close()

# 打个压缩包
epubfile = ZipFile(title+'.epub', 'w')
os.chdir('tmp')
for d, ds, fs in os.walk('.'):
    for f in fs:
        epubfile.write(os.path.join(d, f))
epubfile.close()

print('Finished!')
