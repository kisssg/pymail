from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl import load_workbook
from ExcelMySQL import ExcelMySQL
from os import remove
from sendMailAttachments import send_mail
import datetime

wq = ExcelMySQL()
today = datetime.date.today()
end_day = today - datetime.timedelta(today.weekday())-datetime.timedelta(7)
start_day = end_day - datetime.timedelta(31)
sql_file = "vrd_result_overview.sql"
file = open(sql_file, 'r', encoding='utf-8')
query = file.read().format(start_day, end_day)
file.close()
df = wq.query2df(query)
wb = load_workbook("templates/camera_overview.xlsx")
ws_data = wb['Camera_Scores']
# ws_data.delete_cols(1, 71)
# ws_data.delete_rows(1, 5000)
row = 3
for r in dataframe_to_rows(df, index=False, header=False):
    #     ws_data.append(r)
    col = 1
    for val in r:
        cell = ws_data.cell(row, col)
        if val == "0" or val == "1":
            cell.value = float(val)
        else:
            cell.value = val
        col += 1
    row += 1
ws = wb["Overview"]
pivot = ws._pivots[0]  # any will do as they share the same cache
pivot.cache.refreshOnLoad = True
filename = "Quality overview report-Camera checking {}.xlsx".format(
    end_day.strftime("%Y%m%d"))
wb.save(filename)

mailbody = """Dear All, 

Please find attachment for details, thanks.
Please note that this report is built through python on scheduled task, there might be unexpected results sometime. 
If you got alert to repair the file, click yes. 
Any issues, please kindly let me know, thanks.

Best Regards,
Sucre Xu
Ext. 1623
Late Collection Quality Management
Risk Management Department

""".format(start_day, end_day)
sendto = ['kein.zhang@homecredit.cn', 'andy.hutj@homecredit.cn']
cc = ['lin.xiaodong@homecredit.cn', 'daisy.wu@homecredit.cn', 'huihui.gong@homecredit.cn', 'sophia.guocs@homecredit.cn', 'Collectionanalyticalteam@homecredit.cn',
      'LatecollectionQCdatateam@homecredit.cn']
bcc = ['lingling.zhuchs@homecredit.cn', 'lina.deng@homecredit.cn', 'feng.lin@homecredit.cn', 'sucre.xu@homecredit.cn','ladislav.stary@homecredit.cn',
       'caroline.zhao1@homecredit.cn','skye.cai@homecredit.cn','summer.lee@homecredit.cn','carolyn.wang@homecredit.cn','richie.ruan@homecredit.cn',
       'hailey.wei@homecredit.cn','jeff.gao@homecreditcfc.cn','mancy.zhengtj@homecredit.cn','jayden.zhang1@homecredit.cn','allan.jing@homecreditcfc.cn',
       'evelyn.li@homecredit.cn','tracy.bai@homecreditcfc.cn','aries.hai@homecredit.cn','connie.jin@homecredit.cn','jensen.zhang1@homecredit.cn','ivy.piao@homecredit.cn']
# sendto = ['feng.lin@homecredit.cn']
send_mail("FieldCollectionQM@homecredit.cn", sendto, filename.replace(".xlsx", ""), mailbody,
          [filename], "relay.homecredit.cn",bcc,cc)
remove(filename)
