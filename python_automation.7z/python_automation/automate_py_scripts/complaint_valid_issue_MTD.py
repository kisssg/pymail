from ExcelMySQL import ExcelMySQL
import datetime
from sendMailAttachments import send_mail
import os
wq = ExcelMySQL()

weekday=datetime.date.today().day
start_day = datetime.date.today() - datetime.timedelta(weekday-1)
today = datetime.date.today()
if(today.month == 1):
        last_month_day1 = (datetime.date(today.year-1,12,1))
else:
        last_month_day1 = (datetime.date(today.year,today.month-1,1))
if(datetime.date.today().day < 10):
	start_day = last_month_day1
end_day = datetime.date.today()
# start_day = datetime.date(2021,9,1)
# end_day =  datetime.date(2021,9,30)
filename = "投诉协调组有效违规{:%m%d}-{:%m%d}.xlsx".format(start_day,end_day)
# saveto = "\\\\Hcg.homecredit.net\\cndata\HCCDFS\Restricted\DptRisk\Collection\Late collection QC\FC QC\\video data\VRD每周核查数据\\{:%Y%m}".format(datetime.date.today())
# saveto=".\\{:%Y%m}".format(datetime.date.today())
saveto = "tmp"
query = """
SELECT
	*
FROM
	fc_issue
WHERE
	close_time BETWEEN '{} 00:00:00'AND '{} 23:59:59' #日期区间
	and result ="有效"
  AND source ="complaint coordinator"
""".format(start_day,end_day)
wq.writeToExcel(query,filename,saveto)

mailbody="""Dear Xiaohong,

投诉协调组有效违规{:%m%d}-{:%m%d}:请查看附件。

Best Regards,
QC Data Team

""".format(start_day,end_day)
sendto=['Yue.Zhao@homecredit.cn','Guanhua.Zhang@homecredit.cn','Lvnhoor.Lv@homecredit.cn','Jenny.ZhangTJ@homecredit.cn','Ye.CHEN@homecredit.cn','Danielle.Wang@homecredit.cn','lina.deng@homecredit.cn','feng.lin@homecredit.cn','lingling.zhuchs@homecredit.cn',"bu.yang@homecredit.cn","qianxia.tang@homecredit.cn","jing.sheng@homecredit.cn","kimberly.xun@homecredit.cn"]
# sendto=['sucre.xu@homecredit.cn']
send_mail("sucre.xu@homecredit.cn",sendto,"投诉协调组有效违规{:%m%d}-{:%m%d}".format(start_day,end_day),mailbody,[saveto + "/" + filename ],"127.0.0.1")
os.remove(saveto + "/" + filename)
