from ExcelMySQL import ExcelMySQL
import datetime
from sendMailAttachments import send_mail
import os
wq = ExcelMySQL()

# weekday=datetime.date.today().day
start_day = datetime.date.today() - datetime.timedelta(7)
# today = datetime.date.today()
# if(today.month == 1):
#         month_day1 = (datetime.date(today.year-1,12,1))
# else:
#         month_day1 = (datetime.date(today.year,today.month-1,1))
# if(datetime.date.today().day < 10):
# 	start_day = month_day1
end_day = datetime.date.today() - datetime.timedelta(1)
start_day = datetime.date(2022,9,30)
end_day =  datetime.date(2022,10,6)
filename = "外催有效违规{:%m%d}-{:%m%d}.xlsx".format(start_day,end_day)
saveto = "tmp"
query = """
SELECT
	distinct i.*,
    c.type,
	c.create_type,
	s.col22 AS VRD申诉结果,
	s.remark2 AS VRD申诉及反馈内容,
	s.remark3 AS VRD申诉处理QC,
	a.VISIT_RESULT
FROM
	`fc_issue` i
	LEFT JOIN callback c ON (i.callback_id = c.id and i.source="call back checking")
	LEFT JOIN camera_scores s ON (i.callback_id = s.data_id and i.source="camera checking")
	LEFT JOIN cameras a ON (i.callback_id = a.id and i.source="camera checking")
WHERE
	i.close_time BETWEEN '{} 00:00:00' AND '{} 23:59:59'
	AND result = '有效'
	AND object LIKE '外催员%'
    AND i.deleted_at IS NULL
ORDER BY i.id
""".format(start_day,end_day)
wq.writeToExcel(query,filename,saveto)

mailbody="""Dear(s),

请查收外催有效违规{:%m%d}-{:%m%d}:请查看附件。
本邮件为系统自动生成发送，如发现异常请及时反馈，谢谢。

Best Regards,
QC Data Team

""".format(start_day,end_day)
sendto=['shenglan.yin@homecredit.cn','scarlett.deng@homecredit.cn','sophia.guocs@homecredit.cn','yying.xie@homecredit.cn','sucre.xu@homecredit.cn','feng.lin@homecredit.cn']
# sendto=['sucre.xu@homecredit.cn']
send_mail("sucre.xu@homecredit.cn",sendto,"外催有效违规{:%m%d}-{:%m%d}".format(start_day,end_day),mailbody,[saveto + "/" + filename ],"relay.homecredit.cn")
os.remove(saveto + "/" + filename)
