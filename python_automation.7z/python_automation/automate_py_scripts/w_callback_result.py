from ExcelMySQL import ExcelMySQL
import datetime
from sendMailAttachments import send_mail
import os
wq = ExcelMySQL()

# weekday=datetime.date.today().weekday()
# start_day = datetime.date.today() - datetime.timedelta(weekday+7+1)
# end_day = start_day + datetime.timedelta(6)
today = datetime.date.today()
if(today.month == 1):
    last_month_day1 = (datetime.date(today.year-1, 12, 1))
else:
    last_month_day1 = (datetime.date(today.year, today.month-1, 1))
start_day = last_month_day1
end_day = today - datetime.timedelta(today.day)
filename = "工作量：电话回访_{:%m%d}-{:%m%d}.xlsx".format(start_day, end_day)
# saveto = "\\\\Hcg.homecredit.net\\cndata\HCCDFS\Restricted\DptRisk\Collection\Late collection QC\FC QC\\video data\VRD每周核查数据\\{:%Y%m}".format(datetime.date.today())
saveto = "tmp"
query = """
DROP TEMPORARY TABLE
IF EXISTS tmp_table2;

CREATE TEMPORARY TABLE tmp_table2 (
	SELECT
		a.id AS a,
		b.id AS b,
		c.id AS c,
		d.id as d,
		type,
		contract_no,
		client_name,
		contact_info,
		contact_info2,
		city,
		visit_date,
		responsible_person,
		remark_phone,
		remark_detail,
		actual_paid_amt,
		contact_person,
		is_connected,
		is_meet,
		paid_date,
		paid_method_q3,
		paid_amt_q4,
		is_contacted,
		contact_type,
		contact_info_collector,
		is_harassed,
		issue_type,
		complaint_obj,
		harass_detail,
		issue_time,
		sensitive_word,
		has_evidence,
		evidence_channel,
		has_paid,
		paid_method,
		paid_amount,
		got_understood,
		remark,
		qc_name,
		check_time,
		is_connected_2nd,
		got_understood_2nd,
		got_evidence_2nd,
		evidence_channel_2nd,
		remark_2nd,
		valid_complaint_2nd,
		compaint_type,
		call_time_2nd,
		qc_name_2nd,
		pattern_completed,
		filling_right,
		communication,
		improve_tips,
		recording_remark,
		recording_check_time,
		recording_check_qc,
patternCompleted2,
fillingRight2,
communication2,
remark2,
auditor2,
addDate2,
addTime2
	FROM
		callback a
	LEFT JOIN (SELECT * FROM recallback) b ON b.callback_id = a.id
	LEFT JOIN (
		SELECT
			*
		FROM
			callback_recording
	) c ON c.callback_id = a.id
	left join (select id,cbId,
pattern_completed as patternCompleted2,
filling_right as fillingRight2,
communication as communication2,
remark as remark2,
auditor as auditor2,
addDate as addDate2,
addTime as addTime2
 from call_rec_audits)d on d.cbId=a.id
	WHERE
		a.qc_name NOT IN (
			'已删除',
			'sucre xu',
			'fcqc qc',
			'richard xiao',
			'scarlett deng',
			''
		)
-- AND check_time LIKE '2022-09%' #<<<<<<<<<<<这里改日期。
AND check_time between '{} 00:00:00' and '{} 23:59:59'  
#AND is_connected in ("No interest to cooperate","No answer")
#and contract_no="3639382993002"
);

SELECT
    a,
	type,
	contract_no,
	client_name,
	contact_info,
	contact_info2,
	city,
	visit_date,
	responsible_person,
	remark_phone,
	remark_detail,
	actual_paid_amt,
	contact_person,
	is_connected,
	is_meet,
	paid_date,
	paid_method_q3,
	paid_amt_q4,
	is_contacted,
	contact_type,	
	contact_info_collector,
	is_harassed,
	issue_type,
	complaint_obj,
	harass_detail,
	issue_time,
	sensitive_word,
	has_evidence,
	evidence_channel,
	has_paid,
	paid_method,
	paid_amount,
	got_understood,
	remark,
	qc_name,
	check_time,
	is_connected_2nd,
	got_understood_2nd,
	got_evidence_2nd,
	evidence_channel_2nd,
	remark_2nd,
	valid_complaint_2nd,
	compaint_type,
	call_time_2nd,
	qc_name_2nd,
	NULL as a1,
	NULL as a2,
	NULL as a3,
	NULL as a4,
	NULL as a5,
	pattern_completed,
	filling_right,
	communication,
	improve_tips,
	recording_remark,
	recording_check_time,
	recording_check_qc,
patternCompleted2,
fillingRight2,
communication2,
remark2,
auditor2,
addDate2,
addTime2
FROM
	tmp_table2
""".format(start_day, end_day)

wq.writeToExcel(query, filename, saveto)

mailbody = """Dears,

请查看附件，谢谢。
本邮件及数据为系统自动生成，如发现异常，请及时反馈，谢谢。

Best Regards,
QC Data Team

""".format(start_day, end_day)
sendto = ['yying.xie@homecredit.cn', 'echo.he@homecredit.cn', 'scarlett.deng@homecredit.cn',
          'sophia.guocs@homecredit.cn', 'lina.deng@homecredit.cn','lingling.zhuchs@homecredit.cn', 'sucre.xu@homecredit.cn']
# sendto=['sucre.xu@homecredit.cn']
send_mail("sucre.xu@homecredit.cn", sendto, filename,
          mailbody, [saveto + "/" + filename], "relay.homecredit.cn")
os.remove(saveto + "/" + filename)
