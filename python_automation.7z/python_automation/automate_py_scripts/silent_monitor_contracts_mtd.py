from ExcelMySQL import ExcelMySQL
import datetime
from sendMailAttachments import send_mail
import os
wq = ExcelMySQL()

weekday=datetime.date.today().day
start_day = datetime.date.today() - datetime.timedelta(weekday-1)
today = datetime.date.today()
if(today.month == 1):
        last_month_day1 = (datetime.date(today.year-1,12,1))
else:
        last_month_day1 = (datetime.date(today.year,today.month-1,1))
if(datetime.date.today().day < 10):
	start_day = last_month_day1
end_day = datetime.date.today()
# start_day = datetime.date(2021,9,1)
# end_day =  datetime.date(2021,9,30)
filename = "silent_monitor_contracts_mtd{:%m%d}-{:%m%d}.xlsx".format(start_day,end_day)
# saveto = "\\\\Hcg.homecredit.net\\cndata\HCCDFS\Restricted\DptRisk\Collection\Late collection QC\FC QC\\video data\VRD每周核查数据\\{:%Y%m}".format(datetime.date.today())
# saveto=".\\{:%Y%m}".format(datetime.date.today())
saveto = "tmp"
query = """
DROP TEMPORARY TABLE
IF EXISTS tmp_table2;

CREATE TEMPORARY TABLE tmp_table2 (
	SELECT DISTINCT
		contract_id,
		AVG (Score) AS avg_score
	FROM
		collection_activities_checking_scores 
	WHERE
	 deleted_at is null
	GROUP BY
		contract_id);

SELECT
	id,
	checking_date,
	contract_type,
	lcs AS LCS,
	collector,
	region,
	evid_srv,
	qc_name AS QC,
	CASE (assess_count)
		WHEN - 1 THEN
			0
		WHEN - 2 THEN
			'-'
		ELSE
			assess_count
		END AS recording,
	CASE (assess_count)
		WHEN 0 THEN
			'-'
		WHEN - 1 THEN
			'-'
		WHEN - 2 THEN
			'-'
		ELSE
			(SELECT
				avg_score
			FROM
				tmp_table2 a
			WHERE
				a.contract_id = b.id
			)
		END AS monitoring_score,
	CASE assess_count
		WHEN - 2 THEN
			'N'
		ELSE
			'Y'
		END AS providing_collection_data,
		rec_needed,
		rec_submitted,
		rec_submitted / rec_needed AS matched_call_rate,
		material_needed,
		material_submitted,
		material_submitted / material_needed AS matched_material_rate,
	CASE batch
		WHEN '' THEN
			'add'
		ELSE
			"upload"
		END AS "upload/add",
	b.NAME AS client_name
FROM
	silent_monitor_contract b
WHERE
	qc_name NOT IN ('public.osv','sucre.xu')
    AND checking_date BETWEEN '{}'AND '{}'
    AND deleted_at is null
ORDER BY id
""".format(start_day,end_day)
wq.writeToExcel(query,filename,saveto)

mailbody="""Dear Echo,

催收行为核查合同汇总MTD{:%m%d}-{:%m%d}:请查看附件。

Best Regards,
QC Data Team

""".format(start_day,end_day)
sendto=['echo.he@homecredit.cn','jing.sheng@homecredit.cn','carson.liu@homecredit.cn','feng.lin@homecredit.cn','sucre.xu@homecredit.cn']
# sendto=['sucre.xu@homecredit.cn']
send_mail("sucre.xu@homecredit.cn",sendto,"催收行为核查合同汇总MTD{:%m%d}-{:%m%d}".format(start_day,end_day),mailbody,[saveto + "/" + filename ],"127.0.0.1")
os.remove(saveto + "/" + filename)
