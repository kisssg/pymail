from ExcelMySQL import ExcelMySQL
import datetime
from sendMailAttachments import send_mail
import os
wq = ExcelMySQL()

# weekday=datetime.date.today().weekday()
# start_day = datetime.date.today() - datetime.timedelta(weekday+7+1)
# end_day = start_day + datetime.timedelta(6)
today = datetime.date.today()
if(today.month == 1):
    last_month_day1 = (datetime.date(today.year-1, 12, 1))
else:
    last_month_day1 = (datetime.date(today.year, today.month-1, 1))
start_day = last_month_day1
end_day = today - datetime.timedelta(today.day)
filename = "工作量：VRD内审_{:%m%d}-{:%m%d}.xlsx".format(start_day, end_day)
# saveto = "\\\\Hcg.homecredit.net\\cndata\HCCDFS\Restricted\DptRisk\Collection\Late collection QC\FC QC\\video data\VRD每周核查数据\\{:%Y%m}".format(datetime.date.today())
saveto = "tmp"
query = """
SELECT
	a.SKP_CLIENT,
	a.ID_CUID,
	a.CLIENT_NAME,
	a.TEXT_CONTRACT_NUMBER,
	a.AREA,
	a.NAME_COLLECTOR,
	a.BATCH_NUMBER, 
	a.AGENT_EMPLOYEE_ID,
	a.UNIQUE_DEVICE_ID,
	a.DATE_ASSIGNMENT,
	a.SH_CITY,
	a.SV_NAME,
	a.TL_NAME,
	a.MGR_NAME,
	a.ACTION_DATE,
	a.ACTION_TIME,
	a.VISIT_RESULT,
	a.TEXT_COUNTERPARTY,
	a.TEXT_USER_OF_VEHICLE,
	a.FLAG_WITH_VIDIO,
	a.FLAG_WITH_AUDIO,
	a.FLAG_WITH_ANY,
	a.FLAG_WITH_BOTH,
	a.CREATE_TIME,
	a.ENDING_TIME,
	a.SUM_VIDIO_TIME_DURATION,
	a.SUM_AUDIO_TIME_DURATION,
	a.CNT_VIDEO_RECORDS,
	a.CNT_AUDIO_RECORDS,
	a.ROW_ACTION,
	a.SHORT_TIME_VIDEO,
	a.LONG_TIME_VIDEO,
	a.SHORT_TIME_AUDIO,
	a.LONG_TIME_AUDIO,
	a.UNUSUAL_TIME_TREATION,
	a.FLAG_COLLECTED_LCS,
	a.DESC_COMMENTS,
	a.COLLECTION_TYPE,
	a.recovery_method,
	a.PHONE_NUMBER,
	a.ADDRESS_TYPE,
	a.NUM_LONGITUDE,
	a.NUM_LATITUDE,
	a.TEXT_ADDRESS,
	a.FLAG_VALID,
	a.FLAG_PBOC,
	a. OWNER,
	b.updated_at AS 'checking time',
	col2 AS 'Nothing recorded 全程无声或黑屏',
	col1 AS 'No video & audio recording on visit 没有音视频记录的拜访',
	col3 AS 'Incomplete contract statement 不完整的合同声明',
	col4 AS 'VRD turned off before end of visit or incomplete recording  提前结束录制或不完整的录制',
	col5 AS 'No statement of VRD is on 未声明拍摄',
	col6 AS 'Forged visit log/recording 虚假或无关催收的音视频',
	col19 as 'No skip trace activity无信息搜索活动',
	col7 AS 'Impersonate official to do collection 冒充公职人员进行催收',
	col8 AS 'Provide wrong contract info 提供错误的合同信息',
	col9 AS 'Disclose  contract info to wrong party 泄露贷款等客户信息给错误的人',
	col10 AS 'Push wrong party to pay向错误方催款',
	col11 AS 'Overpromise to client 给出无法合理实现的承诺或期望',
	col12 AS 'No reporting collection result or report untrue collection result  没有提交拜访结果或提交不真实的拜访结果',
	col13 AS 'Dirty words/Provocation/Intimidation 辱骂/挑衅/恐吓',
	col14 AS 'Doing wrong in cash collection though the payment transferred to HCC 转款到公司账上但违反代收现金流程的相关规定',
	col15 AS 'Cash collected without transferring to HCC 未全额转款到公司账上的代收',
	col16 AS 'Blind to client/s reasonable request  玩忽职守无视客户合理需求',
	col17 AS 'Provide false info in name of GOV/Court/Police  以法院/公安/国家等名义提供虚假信息',
	col18 AS 'Disclose client or loan-related information thru public online/offline channel   通过线上/线下渠道来揭示客户或贷款相关的信息',
	col21 AS 'No LLI or visitee/s face and voice recorded  未拍摄LLI本人和沟通方的面容和声音',
	type AS 'type',
	remark1 AS 'Remark',
	b.score AS 'Score',
	b.created_at AS created_at1,
	b.updated_at AS updated_at1,
	b.created_by,
	c.*
FROM
	`cameras` a
LEFT JOIN `camera_scores` b ON b.data_id = a.id
left join `camera_audits` c ON c.data_id=a.id
WHERE
a.deleted_at is null and
	c.created_at BETWEEN '{} 00:00:00' AND '{} 23:59:59' 
-- 以上时间区间为内审提交的时间---------------

-- AND b.created_at between "2021-01-01 00:00:00" and "2021-05-09 23:59:59"    ----核查时间
-- -------------------------------------------
order by c.id
-- -------------------------------------------
-- script created at 13:53:00 2020-06-04
-- author: Sucre Xu


""".format(start_day, end_day)

wq.writeToExcel(query, filename, saveto)

mailbody = """Dears,

请查看附件，谢谢。
本邮件及数据为系统自动生成，如发现异常，请及时反馈，谢谢。

Best Regards,
QC Data Team

""".format(start_day, end_day)
sendto = ['yying.xie@homecredit.cn', 'echo.he@homecredit.cn', 'scarlett.deng@homecredit.cn',
          'sophia.guocs@homecredit.cn', 'lina.deng@homecredit.cn','lingling.zhuchs@homecredit.cn', 'sucre.xu@homecredit.cn']
# sendto=['sucre.xu@homecredit.cn']
send_mail("sucre.xu@homecredit.cn", sendto, filename,
          mailbody, [saveto + "/" + filename], "relay.homecredit.cn")
os.remove(saveto + "/" + filename)
