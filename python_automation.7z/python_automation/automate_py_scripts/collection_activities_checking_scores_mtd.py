from ExcelMySQL import ExcelMySQL
import datetime
from sendMailAttachments import send_mail
import os
wq = ExcelMySQL()

weekday=datetime.date.today().day
start_day = datetime.date.today() - datetime.timedelta(weekday-1)
today = datetime.date.today()
if(today.month == 1):
        last_month_day1 = (datetime.date(today.year-1,12,1))
else:
        last_month_day1 = (datetime.date(today.year,today.month-1,1))
if(datetime.date.today().day < 10):
	start_day = last_month_day1
end_day = datetime.date.today()
# start_day = datetime.date(2021,9,1)
# end_day =  datetime.date(2021,9,30)
filename = "collection_activities_checking_mtd{:%m%d}-{:%m%d}.xlsx".format(start_day,end_day)
# saveto = "\\\\Hcg.homecredit.net\\cndata\HCCDFS\Restricted\DptRisk\Collection\Late collection QC\FC QC\\video data\VRD每周核查数据\\{:%Y%m}".format(datetime.date.today())
# saveto=".\\{:%Y%m}".format(datetime.date.today())
saveto = "tmp"
query = """
SELECT
distinct
	a.id,
	a.Checking_Date,
	a.LCS,
	a.Agency,
	a.Region,
	a.Contract_no,
	a.Call_date,
	a.material_type,
	MAKETIME(seconds div 3600, seconds%3600 div 60, seconds%60) as Duration,
	Case_object,
	item1 AS "Dirty words/Provocation/Intimidation 辱骂/挑衅/恐吓",#1. Dirty words/Provocation/Intimidation 辱骂/挑衅/恐吓
	item2 AS "错误的自我介绍",#2. Incorrect self-introduction 错误的自我介绍
	item3 AS "Provide wrong contract info 提供错误的合同信息",#3. Provide wrong contract info 提供错误的合同信息
	item4 AS "Overpromise to client给出无法合理实现的承诺或期望",#4. Give impossible promise 给出无法合理实现的承诺或期望
	item5 AS "Provide false info in name of GOV/Court/Police 以法院/公安/国家等名义提供虚假信息",#5. Provide false info in name of GOV/Court/Police 以法院/公安/国家等名义提供虚假信息
	item6 AS "利用客户信息采取不当催收方式",#6. Disclose contract info to wrong person 泄露贷款等客户信息给错误的人
	-- item7 AS "Push wrong party to pay向错误方催款",#7. Ignoring family's willingness of 'not paying' for client 向无意愿还款成员催款
	item8 AS "Use unapproved SMS&mail template 使用未得到批复的短信/邮件模板",#8. Use unapproved SMS&mail template 使用未得到批复的短信/邮件模板
	item12 AS "Over-standard frequency collection activities 高频次催收行为",#12. Over-standard frequency collection activities 高频次催收行为
	item9 AS "To do activities of collection at wrong time 在错误的时间的催收活动",#9. Wrong time to do collection 在错误的时间内催收
	item10 AS "Blind to client\'s reasonable request 玩忽职守无视客户合理需求",#10. Ignore collector's duty 玩忽职守无视客户合理需求
	item11 AS "No system log or wrong log 催收系统无备注或错误的备注",#11. No system log or wrong log 催收系统无备注或错误的备注
	item13 AS "Use inappropriate warnings 使用错误的警示",
	Score,
	`Backup`,
	QC,
	b.name client_name,
	b.contract_type,
	CASE b.batch
		WHEN '' THEN
			'add'
		ELSE
			"upload"
	END AS "upload/add"
FROM
	`collection_activities_checking_scores` a	
	left join silent_monitor_contract b on a.contract_id = b.id
WHERE
	a.Checking_Date BETWEEN '{}' AND '{}'   # 这里选择时间区间
	AND a.deleted_at IS NULL  # 这里是排除已删除的
ORDER BY a.id
""".format(start_day,end_day)
wq.writeToExcel(query,filename,saveto)

mailbody="""Dear Echo,

催收行为核查结果汇总MTD{:%m%d}-{:%m%d}:请查看附件。

Best Regards,
QC Data Team

""".format(start_day,end_day)
sendto=['echo.he@homecredit.cn','jing.sheng@homecredit.cn','carson.liu@homecredit.cn','feng.lin@homecredit.cn','sucre.xu@homecredit.cn']
# sendto=['sucre.xu@homecredit.cn']
send_mail("sucre.xu@homecredit.cn",sendto,"外包催收行为核查结果汇总MTD{:%m%d}-{:%m%d}".format(start_day,end_day),mailbody,[saveto + "/" + filename ],"127.0.0.1")
os.remove(saveto + "/" + filename)
