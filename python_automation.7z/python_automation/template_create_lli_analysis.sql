SELECT
  i.id,
  i.`date`,
  i.contract_no,
  i.client_name,
  i.phone,
  i.`object`,
  i.city,
  i.region,
  i.collector,
  case
    (e.tl)
    when "-" then e.sv
    else e.tl
  end as `TL/SV`,
  i.employeeID,
  i.issue_type,
  i.issue,
  i.issue_detail,
  i.remark,
  i.responsible_person,
  i.feedback,
  i.qc_name,
  i.result,
  i.close_reason,
  i.callback_id,
  i.add_time,
  i.feedback_person,
  i.feedback_time,
  i.close_person,
  i.close_time,
  replace(left(i.close_time, 7), "-", "/") as month,
  i.edit_log,
  i.`source`,
  i.harassment_type,
  i.upload_time,
  i.uploader,
  i.deleted_at,
  i.month_belong,
  i.updated_at,
  i.created_at,
  i.source_category,
  i.adjustment_proposed,
  i.adjustment_decided,
  i.adjustment_executed,
  i.letter_id
FROM
  fc_issue i
  LEFT JOIN `fc_employees` e ON e.employee_id = i.employeeID
  and e.deleted_at is null
WHERE
  close_time BETWEEN '{}'
  AND '{} 23:59:59' #日期区间
  AND result = "有效"
  and object in ('外催员/法律调查员', '外催员/法律调查员组长', '外催员/法律调查员主管')
  and issue_type in(
    "Collector's mistake 催收员过错",
    "Collector's attitude 催收员态度"
  )
  order by i.close_time 