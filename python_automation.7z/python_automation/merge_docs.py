from docx import Document
import docx
from docxcompose.composer import Composer
import glob
import os
from pandas import DataFrame
from openpyxl import load_workbook
path = "D:\\Sucre\\OneDrive - 捷信消费金融有限公司\\Human Action\\M&CT"
os.chdir(path)
# wb = load_workbook('names.xlsx')
# ws=(wb['Sheet1'])
# from itertools import islice
# data = ws.values
# cols = next(data)[0:]
# data = list(data)
# idx = [r[0] for r in data]
# data = (islice(r, 0, None) for r in data)
# df = DataFrame(data,columns=cols)
# for r in range(df['new'].count()):
#     if os.path.isfile(df.loc[r].original):
#         os.rename(df.loc[r].original,df.loc[r].new)
duplicates = glob.glob("*.docx")
print((duplicates))   
 
def combine_word_documents(files):
    combined_document = Document('empty.docx')
    count, number_of_files = 0, len(files)
    for file in files:
        sub_doc = Document(file)
 
        # Don't add a page break if you've
        # reached the last file.
        if count < number_of_files - 1:
            sub_doc.add_page_break()
 
        for paragraph in sub_doc.paragraphs:
            text = paragraph.text
            combined_document.add_paragraph(text)
        count += 1
 
    combined_document.save('combined_word_documents.docx')
 
# combine_word_documents(duplicates)
master = Document("whole.docx")
composer = Composer(master)
for f in duplicates:
    if f=='whole.docx':
        break
    doc1 = Document(f)
    doc1.add_page_break()
    composer.fix_section_types(doc1)
    composer.fix_header_and_footers(doc1)
    composer.append(doc1)
master.save('final.docx')  