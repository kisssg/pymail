from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl import load_workbook
from ExcelMySQL import ExcelMySQL
from os import remove, path
from sendMailAttachments import send_mail
import datetime

wq = ExcelMySQL()
today = datetime.date.today()
end_day = today - datetime.timedelta(today.weekday())-datetime.timedelta(1)
# end_day = datetime.date(2022, 3, 15)
if end_day.month <= 5:
    start_day = datetime.date(end_day.year - 1, end_day.month + 7, 1)
else:
    start_day = datetime.date(end_day.year, end_day.month - 5, 1)
sql_file = "template_create_lli_analysis.sql"
root = path.dirname(__file__)
file = open(root + '/' + sql_file, 'r', encoding='utf-8')
query = file.read().format(start_day, end_day)
file.close()
df = wq.query2df(query)
wb = load_workbook(root + "/templates/lli_issue_analysis.xlsx")
ws_data = wb['data']
# ws_data.delete_cols(1, 71)
# ws_data.delete_rows(1, 5000)
# row = 3
for r in dataframe_to_rows(df, index=False, header=True):
    ws_data.append(r)
    # col = 1
    # for val in r:
    #     cell = ws_data.cell(row, col)
    #     if val == "0" or val == "1":
    #         cell.value = float(val)
    #     else:
    #         cell.value = val
    #     col += 1
    # row += 1
ws = wb["月度违规数量"]
pivot = ws._pivots[0]  # any will do as they share the same cache
pivot.cache.refreshOnLoad = True
filename = "Analysis on LLI issues{}.xlsx".format(
    end_day.strftime("%Y%m%d"))
wb.save(filename)

mailbody = """Dear Andy， 

附件为20220501-20221023 外催员有效违规情况，请查收。
自动化报表，如发现异常请与我联系，谢谢。

Best Regards,
Sucre Xu
Ext. 1623
Late Collection Quality Management
Risk Management Department

""".format(start_day, end_day)
sendto = ['andy.hutj@homecredit.cn']
cc = ['huihui.gong@homecredit.cn', 'LatecollectionQCdatateam@homecredit.cn']
bcc = ['lingling.zhuchs@homecredit.cn', 'lina.deng@homecredit.cn',
       'feng.lin@homecredit.cn', 'sucre.xu@homecredit.cn']
# sendto = bcc = cc = ['lina.deng@homecredit.cn', 'feng.lin@homecredit.cn',
#                      'lingling.zhuchs@homecredit.cn', 'sucre.xu@homecredit.cn']
send_mail("Sucre.XU@homecredit.cn", sendto, filename.replace(".xlsx", ""), mailbody,
          [filename], "relay.homecredit.cn", bcc, cc)
remove(filename)
