SELECT
  	a.id,
	a.SKP_CLIENT,
	a.ID_CUID,
  	a.CLIENT_NAME,
	a.TEXT_CONTRACT_NUMBER,
	a.NAME_COLLECTOR,
	a.BATCH_NUMBER,
	a.AGENT_EMPLOYEE_ID,
	a.UNIQUE_DEVICE_ID,
	a.DATE_ASSIGNMENT,
	a.SH_CITY,
	e.area as AREA,
	case (e.tl)
        when "-" then e.sv
        else e.tl
        end as `TL/SV_NAME`,
	e.manager as MGR_NAME,
	a.ACTION_DATE,
	a.ACTION_TIME,
	a.VISIT_RESULT,
  	a.TEXT_COUNTERPARTY,
  	a.TEXT_USER_OF_VEHICLE,
	a.FLAG_WITH_VIDIO,
	a.FLAG_WITH_AUDIO,
	a.FLAG_WITH_ANY,
	a.FLAG_WITH_BOTH,
	a.CREATE_TIME,
	a.ENDING_TIME,
	a.SUM_VIDIO_TIME_DURATION,
	a.SUM_AUDIO_TIME_DURATION,
	a.CNT_VIDEO_RECORDS,
	a.CNT_AUDIO_RECORDS,
	a.ROW_ACTION,
	a.SHORT_TIME_VIDEO,
	a.LONG_TIME_VIDEO,
	a.SHORT_TIME_AUDIO,
	a.LONG_TIME_AUDIO,
	a.UNUSUAL_TIME_TREATION,
	a.FLAG_COLLECTED_LCS,
	a.DESC_COMMENTS,
	a.COLLECTION_TYPE,
	a.recovery_method,
	a.PHONE_NUMBER,
	a.ADDRESS_TYPE,
	a.NUM_LONGITUDE,
	a.NUM_LATITUDE,
	a.TEXT_ADDRESS,
	a.FLAG_VALID,
	a.FLAG_PBOC,
	b.created_by AS OWNER,
   	b.created_at AS 'checking time',
   	case (col2)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'Nothing recorded 全程无声或黑屏',
	case (col1)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'No video & audio recording on visit 没有音视频记录的拜访',
	case (col3)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'Incomplete contract statement 不完整的合同声明',
	case (col4)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'VRD turned off before end of visit or incomplete recording  提前结束录制或不完整的录制',
	case (col5)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'No statement of VRD is on 未声明拍摄',
	case (col6)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'Forged visit log/recording 虚假或无关催收的音视频',
	case (col19)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  as 'No skip trace activity无信息搜索活动',
	case (col7)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'Impersonate official to do collection 冒充公职人员进行催收',
	case (col8)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'Provide wrong contract info 提供错误的合同信息',
	case (col9)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'Disclose  contract info to wrong party 泄露贷款等客户信息给错误的人',
	case (col10)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'Push wrong party to pay向错误方催款',
	case (col11)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'Overpromise to client 给出无法合理实现的承诺或期望',
	case (col12)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'No reporting collection result or report untrue collection result  没有提交拜访结果或提交不真实的拜访结果',
	case (col13)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'Dirty words/Provocation/Intimidation 辱骂/挑衅/恐吓',
	case (col14)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'Doing wrong in cash collection though the payment transferred to HCC 转款到公司账上但违反代收现金流程的相关规定',
	case (col15)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'Cash collected without transferring to HCC 未全额转款到公司账上的代收',
	case (col16)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'Blind to client/s reasonable request  玩忽职守无视客户合理需求',
	case (col17)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'Provide false info in name of GOV/Court/Police  以法院/公安/国家等名义提供虚假信息',
	case (col18)
        when "-" then ""
        when "1" then "-"
        else 1
    end  AS 'Disclose client or loan-related information thru public online/offline channel   通过线上/线下渠道来揭示客户或贷款相关的信息',
	case (col21)
        when "-" then ""
        when "1" then "-"
        else "1"
    end  AS 'No LLI or visitee/s face and voice recorded  未拍摄LLI本人和沟通方的面容和声音',
	remark1 AS 'Remark',
	CAST(b.score as UNSIGNED) AS 'Score',
  	CAST(checked as UNSIGNED) AS 'Checked'
FROM
	`cameras` a
LEFT JOIN `camera_scores` b ON b.data_id = a.id
LEFT JOIN `fc_employees` e ON e.employee_id = a.AGENT_EMPLOYEE_ID and e.deleted_at is null 
WHERE
	a.deleted_at is null 
	AND b.deleted_at is null 
	AND a.checked = "1"
	AND a.ACTION_DATE between '{}' and '{}'
ORDER BY a.id
-- -------------------------------------------
-- 更新记录-----------------------------------
-- 新增打分项：No skip trace activity无信息搜索活动 20200604
-- 修改打分项：No system log or wrong log 日志中选择错误项或未提交日志 20200604