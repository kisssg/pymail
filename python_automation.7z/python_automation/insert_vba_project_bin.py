import xlsxwriter
book = xlsxwriter.Workbook("macro_xlxswriter.xlsm")
sheet = book.add_worksheet("Sheet1")
sheet.write("A1", "Click the button!")
book.add_vba_project("vbaProject.bin")
# sheet.insert_button("A3", {"macro": "Hello", "caption": "Button 1",
# "width": 130, "height": 35})
book.close()