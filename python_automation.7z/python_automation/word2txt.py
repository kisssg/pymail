from win32com import client
# https://www.cnblogs.com/zhuminghui/p/11765401.html#!comments
msword = client.Dispatch("Word.application")
msword.Visible=0
msword.DisplayAlerts=0

doc = msword.Documents.Open("D:\\Sucre\\python_automation\\1.docx")
doc.SaveAs('test.txt',4)
doc.Close

msword.Quit()