import datetime
import glob
import os
path = "C:\\Users\\Sucre.xu\\Documents\\WeChat Files\\devidelong\\FileStorage\\File\\2022-08"
os.chdir(path)
duplicates = glob.glob("*([1-9])*")
print(duplicates)
for i in duplicates:
    os.remove(i)