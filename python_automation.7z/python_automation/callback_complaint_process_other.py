from ExcelMySQL import ExcelMySQL
import datetime
from sendMailAttachments import send_mail
wq = ExcelMySQL()

weekday=datetime.date.today().weekday()
start_day2 = datetime.date.today() - datetime.timedelta(weekday+3)
end_day2 = start_day2 + datetime.timedelta(6)

start_day1 = datetime.date.today() - datetime.timedelta(weekday+3+7)
end_day1 = start_day1 + datetime.timedelta(6)

filename1 = "Callback流程+其它{:%m%d}-{:%m%d}.xlsx".format(start_day1,end_day1)
filename2 = "Callback流程+其它{:%m%d}-{:%m%d}.xlsx".format(start_day2,end_day2)

# saveto = "\\\\hc.cn\hccdfs\Restricted\DptRisk\Collection\Late collection QC\FC QC\\video data\VRD每周核查数据\\{:%Y%m}".format(datetime.date.today())
saveto=".\\{:%Y%m}".format(datetime.date.today())
query = """
SELECT
	*
FROM
	`callback`
WHERE
	is_harassed = 'Y 是'        -- Q7是否有困扰
	AND  replace(replace(replace(got_understood,char(9),''),char(10),''),char(13),'')!= "Y 是" -- 更新20210326 Q14是否接受解释，包含“-” 和 “N 否”
-- 这里是（流程+其他）的违规，如果这类违规有更新，记得这里要一起更新
	AND issue_type IN (
		'To get the contract 客户未收到合同',
		'Special Case 特殊案件',
		'Collection call/sms 催收电话/催收短信',
		'Too many SMS 短信轰炸',
		'Did not get goods 客户未拿到商品',
		'Repayment 偿还欠款',
		'Cash out/Did not deal with business 套现/未办理业务',
		'Unable to get 无法获取/无法归纳',
		'Penalty 罚金/滞纳金/费用明细',
		'Too many calls 电话轰炸',
		'Business error 业务办理错误',
		'bad manners 恶劣的语气语调'
		) 
	AND check_time BETWEEN '{} 00:00:00' AND '{} 23:00:00'
ORDER BY id

-- 这里导出来是 （流程+其他）的违规，后续不会再调查，直接给投诉协调组登记DCM
"""
query1=query.format(start_day1,end_day1)
query2=query.format(start_day2,end_day2)

wq.writeToExcel(query1,filename1,saveto)
wq.writeToExcel(query2,filename2,saveto)
mailbody="""Dear Xiaohong,

投诉（流程+其他）{:%m%d}-{:%m%d}:请查看附件。
投诉（流程+其他）{:%m%d}-{:%m%d}:请查看附件。

Best Regards,
QC Data Team

""".format(start_day2,end_day2,start_day1,end_day1)
sendto=['Yue.Zhao@homecredit.cn','Guanhua.Zhang@homecredit.cn','Lvnhoor.Lv@homecredit.cn','Jenny.ZhangTJ@homecredit.cn','Ye.CHEN@homecredit.cn','Fifi.ZHENG@homecredit.cn','Danielle.Wang@homecredit.cn','lina.deng@homecredit.cn','feng.lin@homecredit.cn','lingling.zhuchs@homecredit.cn']
# sendto=['sucre.xu@homecredit.cn']
send_mail("sucre.xu@homecredit.cn",sendto,"callback投诉需登记DCM的数据02",mailbody,[saveto + "\\" + filename1,saveto + "\\" + filename2 ],"relay.homecredit.cn")
